# Core contract · v1

`loomsci_core` is the small, stable head of the product. Full TAA is **Core +
add-ons**, not a larger Core. Add-ons attach through frozen contracts; they do
not force a Core rewrite.

## Core v1: what must be true

1. **One machine, one owner, one main agent** (`alice`), plus optional agents.
2. **One command start**: `loomsci init` then `loomsci serve`; loopback only,
   no login, no center, no TLS requirement.
3. **Identity**: `<agent>.<owner>`, persona, instructions, adapters, rename
   history, persona snapshots.
4. **Bus**: posts, tasks, claim/lease, handoff, read cursors, presence.
5. **Memory**: project facts and preferences that can be written, recalled,
   reviewed, exported, and reverted. No secrets; no uncontrolled drift.
6. **Assets**: project files, artifacts, attachments.
7. **UI**: read plus minimal write (post, task, memory review), not read-only.
8. **Operations**: export/import, backup, diagnostics, install, upgrade,
   rollback.
9. **Platforms**: macOS and Windows install/upgrade.
10. **IDE clients**: opencode + omp validated; WorkBuddy / codebuddy / Qoder
    adapters documented and at least one GUI client validated.
11. **Security**: loopback, Host/Origin/JSON boundary, no anonymous private
    reads, sanitization before every push.
12. **Tests**: L0–L7 from `docs/en/testing.md`; real IDE handoff; migration.

## Not Core (add-ons)

- multi-agent rooms, roles, E2EE, share/QR/invite;
- center, peer sync, federation, tunnel, discovery;
- public feed, moments, friends visibility;
- research, monograph, LoomDoc, media/video;
- APK/IPA distribution;
- LAN pairing, multi-user, plugin marketplace.

The Core keeps the **host contract** for these: pack registry, `/apps/<slug>/`
namespace, namespaced storage, and a single event/audit path.

## Frozen contracts (change only with a versioned Core release)

- `agent.owner` handles and stable agent ids;
- home layout: `core/`, `data/`, `agents/`, `packs/`, `logs/`, `runtime/`;
- SQLite IDs and additive-only migrations (except the explicitly approved
  `v0.1.0-beta.2` removal of `posts.title`);
- `/v1` HTTP shapes and `loomsci` CLI names;
- post/task/lease/handoff semantics;
- posts are one canonical Markdown body. `title` is not part of the model;
  long posts may have a derived `summary` (300–500 characters) in
  `post_summaries`;
- export zip format and manifest version;
- pack registry (routes/jobs/nav);
- install/upgrade manifest (`preserve` / `forbid_overwrite`);
- prompt policy: hard invariants + adaptation budget.

## Node sequence

| Node | Goal | Exit gate |
|---|---|---|
| N0 · done | Contract freeze 1 (`v0.1.0-preview.6`) | install, bus, alice, agent add, export/import, UI, release, real opencode+omp handoff |
| N1 · done | Core Alpha (`v0.1.0-preview.7`) | init, post/task UI writes, memory add/review/export; Windows install spike passed |
| N2 · done | Core Beta (`v0.1.0-preview.8`) | search, watch/SSE, inbox/mentions, attachments, status recovery; restart/replay tests |
| N3 · done (scope adjusted) | Core RC (`v0.1.0-preview.15`) | macOS L0–L7, Windows L0–L6, upgrade/rollback, migration; unsigned/no GitHub Release accepted |
| **N4 · current** | scenario suite and freeze | deterministic macOS/Windows scenarios ([n4-acceptance](n4-acceptance.md)); no wall-clock soak; no new features |

Add-ons start only after N4. Suggested order: app host + first app, collab,
sync, media/dist, social.

## Today's endpoint

`v0.1.0-preview.6` remains the foundation freeze. N1–N3 are complete at
`preview.15`, with signing and GitHub Release explicitly out of scope. Current
work is N4: soak, bug fixes only, documentation freeze.
